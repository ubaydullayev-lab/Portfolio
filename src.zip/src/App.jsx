import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


import { Layout, Menu, Button, Typography, Row, Col, Image, Card, Tag, List, Avatar } from 'antd';
import { CheckOutlined } from '@ant-design/icons';

const { Header, Content, Footer } = Layout;
const { Title, Paragraph } = Typography;

const meals = [
  {
    title: 'Yapon Gyozalari',
    calories: 650,
    nutriScore: 74,
    rating: 4.9,
    votes: 537,
    tag: 'Vegetarian',
    img: 'https://omnifood.dev/img/meals/meal-1.jpg',
  },
  {
    title: 'Avakado salatasi',
    calories: 400,
    nutriScore: 92,
    rating: 4.8,
    votes: 441,
    tag: 'Vegetarian',
    img: 'https://omnifood.dev/img/meals/meal-2.jpg',
  },
];

const diets = [
  'Vegetarian', 'Vegan', 'Peskatarian', 'Glyutensiz', 'Laktozasiz', 'Keto', 'Paleo', 'Past FODMAP', 'Bolalar uchun qulay'
];

const testimonials = [
  {
    name: 'Deyv Brayson',
    img: 'https://omnifood.dev/img/customers/dave.jpg',
    text: "Arzon, sog'lom va mazali taomlar, hatto qo'lda buyurtma bermasdan! Bu haqiqatan ham sehrli tuyuladi."
  },
  {
    name: 'Ben Xedli',
    img: 'https://omnifood.dev/img/customers/ben.jpg',
    text: "AI algoritmi juda yaxshi, u har safar men uchun to'g'ri taomlarni tanlaydi."
  },
];

const App = () => {
  return (
    <Layout>
      <Header style={{ display: 'flex', justifyContent: 'space-between', backgroundColor: '#fdf2e9' }}>
        <img src="https://omnifood.dev/img/omnifood-logo.png" alt="logo" style={{ height: 30 }} />
        <Menu mode="horizontal" style={{ backgroundColor: 'transparent' }}>
          <Menu.Item>Qanday ishlaydi</Menu.Item>
          <Menu.Item>Ovqatlar</Menu.Item>
          <Menu.Item>Guvohlar</Menu.Item>
          <Menu.Item>Narxlash</Menu.Item>
        </Menu>
        <Button type="primary" style={{ backgroundColor: '#f78624', border: 'none' }}>Bepul sinab ko'ring</Button>
      </Header>

      <Content style={{ padding: '50px', backgroundColor: '#fdf2e9' }}>
        <Row gutter={32} align="middle">
          <Col span={12}>
            <Title>Eshigingizga har kuni yetkazib beriladigan sog'lom taom</Title>
            <Paragraph style={{ fontSize: 18, color: '#555' }}>
              Yiliga 365 kunlik aqlli oziq-ovqat obunasi sizni yana sog'lom ovqatlanishga majbur qiladi.
              Sizning shaxsiy didingiz va ovqatlanish ehtiyojlaringizga moslashtirilgan.
            </Paragraph>
            <Button type="primary" size="large" style={{ marginRight: 16 }}>Yaxshi ovqatlanishni boshlang</Button>
            <Button size="large">Batafsil ma'lumot👇</Button>
          </Col>
          <Col span={12}>
            <Image src="https://omnifood.dev/img/hero.webp" preview={false} />
          </Col>
        </Row>

        <Title level={2} className="mt-5">Ovqatlar</Title>
        <Row gutter={24}>
          {meals.map((meal, index) => (
            <Col span={8} key={index}>
              <Card cover={<img alt={meal.title} src={meal.img} />}> 
                <Tag color="green">{meal.tag}</Tag>
                <Title level={3}>{meal.title}</Title>
                <Paragraph>🔥 {meal.calories} kaloriya</Paragraph>
                <Paragraph>🍴 NutriScore: {meal.nutriScore}</Paragraph>
                <Paragraph>⭐ {meal.rating} reyting ({meal.votes})</Paragraph>
              </Card>
            </Col>
          ))}

          <Col span={8}>
            <Card>
              <Title level={3}>Har qanday parhezga mos:</Title>
              <List
                dataSource={diets}
                renderItem={(item) => (
                  <List.Item><CheckOutlined style={{ color: 'green' }} /> {item}</List.Item>
                )}
              />
            </Card>
          </Col>
        </Row>

        <Title level={2} className="mt-5">Guvohlar</Title>
        <Row gutter={24}>
          {testimonials.map((t, index) => (
            <Col span={12} key={index}>
              <Card>
                <Card.Meta
                  avatar={<Avatar src={t.img} size={64} />}
                  title={t.name}
                  description={t.text}
                />
              </Card>
            </Col>
          ))}
        </Row>
      </Content>

      <Footer style={{ textAlign: 'center' }}>
        ©2025 OmniFood. Barcha huquqlar himoyalangan.
      </Footer>
    </Layout>
  );
};

export default App;

